// Nazanin Zahra Taghizadeh 40223022
#include <stdio.h>
#include <math.h>
void solver(float * , float * , float *, float * , float *);
int main (void) 
{
    printf("Hello welcome to this Project\n");
    printf("Please enter a:\t");
    float a;
    float b;
    float c;
    float x=0;
    float x1=0;
    scanf("%f",&a);
    printf("Please enter b:\t");
    scanf("%f",&b);
    printf("Please enter c:\t");
    scanf("%f",&c);
    if ((a==0) && (b==0))
    printf("Wrong number");
    else
    {
    float *pa=&a;
    float *pb=&b;
    float *pc=&c;
    float *px=&x;
    float *px1=&x1;
    solver(pa,pb,pc,px,px1);
    if (((b*b)-(4*a*c))==0)
    printf("%f",*px);
    if (((b*b)-(4*a*c))>0)
    printf("%f , %f",*px,*px1);
    }
    
    return 0;
}
void solver(float *a , float *b , float *c , float *x , float *x1)
{
    if (((*b**b)-(4**a**c)) <0)
    {
    printf("This equation has no real roots");
    }
    else if (((*b**b)-(4**a**c))==0)
    {
    printf("It has one root:\t");
    *x=(-*b)/(2**a);
    }
    else
    {
    printf("It has two roots:\t");  
    *x=(-*b+sqrt((*b**b)-(4**a**c)))/(2**a);
    *x1=(-*b-sqrt((*b**b)-(4**a**c)))/(2**a);

    }  
}


