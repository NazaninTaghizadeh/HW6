// Nazanin Zahra Taghizadeh 40223022
#include <stdio.h>
#include <math.h>
float x1,x2,x;
float * solver2(float *, float *, float *);
float * solver(float * , float * , float *);
int main (void) 
{
    printf("Hello welcome to this Project\n");
    printf("Please enter a:\t");
    float a;
    float b;
    float c;
    scanf("%f",&a);
    printf("Please enter b:\t");
    scanf("%f",&b);
    printf("Please enter c:\t");
    scanf("%f",&c);
    if ((a==0) && (b==0))
    printf("Wrong number");
    else
    {
    float *pa=&a;
    float *pb=&b;
    float *pc=&c;
    printf("%f ",*solver(pa,pb,pc));
    printf("and %f",*solver2(pa,pb,pc));
    }
    return 0;
}
float * solver(float *a , float *b , float *c)
{
    if (((*b**b)-(4**a**c)) <0)
    {
    printf("This equation has no real roots");
    }
    else if (((*b**b)-(4**a**c))==0)
    {
    printf("It has one root:\t");
    x=(-*b)/(2**a);
    return &x;
    }
    else
    {
    printf("It has two roots:\t");  
    x1=(-*b+sqrt((*b**b)-(4**a**c)))/(2**a);
    return &x1;
    }  
}
float * solver2(float *a , float *b , float *c)
{
    if (((*b**b)-(4**a**c))>0) 
    {
    x2=(-*b-sqrt((*b**b)-(4**a**c)))/(2**a);
    return &x2;
    }

}  
